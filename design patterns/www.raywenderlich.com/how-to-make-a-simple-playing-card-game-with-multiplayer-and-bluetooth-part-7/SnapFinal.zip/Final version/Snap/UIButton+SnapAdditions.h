
@interface UIButton (SnapAdditions)

- (void)rw_applySnapStyle;

@end
