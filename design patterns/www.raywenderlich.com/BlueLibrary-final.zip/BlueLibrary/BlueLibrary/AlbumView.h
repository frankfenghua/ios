//
//  AlbumView.h
//  BlueLibrary
//
//  Created by Eli Ganem on 15/8/13.
//  Copyright (c) 2013 Eli Ganem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlbumView : UIView

- (id)initWithFrame:(CGRect)frame albumCover:(NSString*)albumCover;

@end
