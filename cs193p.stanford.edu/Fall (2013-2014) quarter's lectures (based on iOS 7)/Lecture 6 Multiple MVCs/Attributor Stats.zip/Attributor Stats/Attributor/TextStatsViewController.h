//
//  TextStatsViewController.h
//  Attributor
//
//  Created by CS193p Instructor on 10/9/13.
//  Copyright (c) 2013 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextStatsViewController : UIViewController

@property (nonatomic, strong) NSAttributedString *textToAnalyze;

@end
