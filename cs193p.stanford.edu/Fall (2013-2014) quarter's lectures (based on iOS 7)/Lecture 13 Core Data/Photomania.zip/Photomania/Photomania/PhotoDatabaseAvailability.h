//
//  PhotoDatabaseAvailability.h
//  Photomania
//
//  Created by CS193p Instructor.
//  Copyright (c) 2013 Stanford University. All rights reserved.
//

#ifndef Photomania_PhotoDatabaseAvailability_h
#define Photomania_PhotoDatabaseAvailability_h

#define PhotoDatabaseAvailabilityNotification @"PhotoDatabaseAvailabilityNotification"
#define PhotoDatabaseAvailabilityContext @"Context"

#endif
