//
//  PhotosCDTVC.h
//  Photomania
//
//  Created by CS193p Instructor.
//  Copyright (c) 2013 Stanford University. All rights reserved.
//

#import "CoreDataTableViewController.h"

@interface PhotosCDTVC : CoreDataTableViewController

// generic Photo displaying CDTVC
// hook up fetchedResultsController to any Photo fetch request
// use @"Photo Cell" as your table view cell's reuse id
// will segue to showing the image in an ImageViewController

@end
