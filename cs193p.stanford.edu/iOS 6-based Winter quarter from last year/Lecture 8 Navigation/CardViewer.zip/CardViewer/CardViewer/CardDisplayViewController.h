//
//  CardDisplayViewController.h
//  CardViewer
//
//  Created by CS193p Instructor.
//  Copyright (c) 2013 Stanford University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardDisplayViewController : UIViewController

@property (nonatomic) NSUInteger rank;
@property (nonatomic, strong) NSString *suit;

@end
