//
//  KitchenSinkViewController.h
//  KitchenSink
//
//  Created by CS193p Instructor.
//  Copyright (c) 2013 Stanford University. All rights reserved.
//
//  Created automatically by Xcode at project creation time.

#import <UIKit/UIKit.h>

@interface KitchenSinkViewController : UIViewController

@end
