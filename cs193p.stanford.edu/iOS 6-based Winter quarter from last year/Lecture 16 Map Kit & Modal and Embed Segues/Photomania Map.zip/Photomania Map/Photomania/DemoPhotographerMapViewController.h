//
//  DemoPhotographerMapViewController.h
//  Photomania
//
//  Created by CS193p Instructor.
//  Copyright (c) 2013 Stanford University. All rights reserved.
//

#import "PhotographerMapViewController.h"

@interface DemoPhotographerMapViewController : PhotographerMapViewController

// this class just uses "Demo Document"'s managedObjectContext
//   as the Model inherits from its superclass

@end
